# frozen_string_literal: false
#
#   tkmngfocus.rb - load tk/mngfocus.rb
#
require 'tk/mngfocus'
