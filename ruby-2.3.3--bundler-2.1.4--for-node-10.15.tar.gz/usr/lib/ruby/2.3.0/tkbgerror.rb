# frozen_string_literal: false
#
#   tkbgerror.rb - load tk/bgerror.rb
#
require 'tk/bgerror'
