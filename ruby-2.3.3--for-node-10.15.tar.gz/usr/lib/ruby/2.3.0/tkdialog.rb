# frozen_string_literal: false
#
#   tkdialog.rb - load tk/dialog.rb
#
require 'tk/dialog'
